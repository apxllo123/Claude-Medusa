export * from "./star-rating";
