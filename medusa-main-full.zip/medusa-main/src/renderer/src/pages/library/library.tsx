import {
  useDeferredValue,
  useEffect,
  useMemo,
  useState,
  useCallback,
  useRef,
} from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import {
  useLibrary,
  useAppDispatch,
  useAppSelector,
  useGameCollections,
  useUserDetails,
} from "@renderer/hooks";
import { setHeaderTitle } from "@renderer/features";
import {
  HeartIcon,
  TelescopeIcon,
  FileDirectoryIcon,
  SearchIcon,
  SyncIcon,
} from "@primer/octicons-react";
import { useTranslation } from "react-i18next";
import { AuthPage, removeDiacritics } from "@shared";
import { GameCollection, LibraryGame } from "@types";
import { CreateCollectionModal, GameContextMenu } from "@renderer/components";
import { useCollectionContextMenu } from "@renderer/context";
import { getGameCollectionIds, sortLibraryGames } from "@renderer/helpers";
import { useSearchParams } from "react-router-dom";
import { LibraryGameCard } from "./library-game-card";
import { LibraryGameCardLarge } from "./library-game-card-large";
import { ViewOptions, ViewMode } from "./view-options";
import { FilterOptions, SortOption } from "./filter-options";
import { CategoryFilter, LibraryCategory } from "./category-filter";
import { PlatformFilter } from "./platform-filter";
import { CollectionsFilter } from "./collections-filter";
import {
  ClassicsOnboardingModal,
  hasDismissedClassicsOnboarding,
} from "@renderer/components/classics-onboarding-modal/classics-onboarding-modal";
import "./library.scss";

const FAVORITES_COLLECTION_ID = "__favorites__";
const GAP = 16;
const LARGE_CARD_ESTIMATED_HEIGHT = 300;
const FALLBACK_ITEM_WIDTH = 150;

const COLUMN_BREAKPOINTS = [3000, 2600, 2000, 1300, 900] as const;
const COLUMNS: Record<"grid" | "compact", readonly number[]> = {
  grid: [12, 8, 6, 5, 4, 2],
  compact: [14, 12, 9, 7, 5, 3],
};

const getColumnsCount = (width: number, mode: ViewMode): number => {
  if (mode === "large") return width >= 900 ? 2 : 1;
  const idx = COLUMN_BREAKPOINTS.findIndex((bp) => width >= bp);
  return COLUMNS[mode][idx === -1 ? COLUMN_BREAKPOINTS.length : idx];
};
const SORT_OPTIONS: SortOption[] = [
  "title_asc",
  "recently_played",
  "most_played",
  "achievements",
  "installed_first",
  "title_desc",
];

export default function Library() {
  const { library, updateLibrary } = useLibrary();
  const { userDetails } = useUserDetails();
  const {
    collections,
    loadCollections,
    hasLoaded: hasLoadedCollections,
  } = useGameCollections();
  const [searchParams, setSearchParams] = useSearchParams();
  const { openCollectionContextMenu } = useCollectionContextMenu();

  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    const savedViewMode = localStorage.getItem("library-view-mode");
    return (savedViewMode as ViewMode) || "compact";
  });
  const [sortBy, setSortBy] = useState<SortOption>(() => {
    const savedSortBy = localStorage.getItem("library-sort-by");
    if (savedSortBy && SORT_OPTIONS.includes(savedSortBy as SortOption)) {
      return savedSortBy as SortOption;
    }

    return "title_asc";
  });
  const [gameContextMenu, setGameContextMenu] = useState<{
    game: LibraryGame | null;
    visible: boolean;
    position: { x: number; y: number };
  }>({ game: null, visible: false, position: { x: 0, y: 0 } });
  const [showCreateCollectionModal, setShowCreateCollectionModal] =
    useState(false);

  const [category, setCategory] = useState<LibraryCategory>(() => {
    const saved = localStorage.getItem("library-category");
    if (saved === "all" || saved === "pc" || saved === "classics") {
      return saved;
    }
    return "all";
  });
  const [selectedPlatform, setSelectedPlatform] = useState<string | null>(null);
  const [isImportingClassics, setIsImportingClassics] = useState(false);

  // The category switch and platform filter are always available, so the
  // selected category is honoured even before any classics games exist.
  const effectiveCategory: LibraryCategory = category;

  const [showClassicsOnboarding, setShowClassicsOnboarding] = useState(false);
  const classicsOnboardingTriggeredRef = useRef(false);

  const gamesScrollRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(0);
  const [isGamesScrolled, setIsGamesScrolled] = useState(false);
  const [isHeaderHidden, setIsHeaderHidden] = useState(false);
  const isHeaderHiddenRef = useRef(false);

  const setHeaderHidden = useCallback((next: boolean) => {
    isHeaderHiddenRef.current = next;
    setIsHeaderHidden(next);
  }, []);

  const handleGamesScroll = useCallback(
    (event: React.UIEvent<HTMLDivElement>) => {
      setIsGamesScrolled(event.currentTarget.scrollTop > 0);
    },
    []
  );

  useEffect(() => {
    const el = gamesScrollRef.current;
    if (!el) return;

    const handleWheel = (event: WheelEvent) => {
      if (event.deltaY > 0) {
        if (!isHeaderHiddenRef.current) {
          event.preventDefault();
          el.scrollTo({ top: el.scrollTop, behavior: "auto" });
          setHeaderHidden(true);
        }
      } else if (event.deltaY < 0 && isHeaderHiddenRef.current) {
        event.preventDefault();
        el.scrollTo({ top: el.scrollTop, behavior: "auto" });
        setHeaderHidden(false);
      }
    };

    el.addEventListener("wheel", handleWheel, { passive: false });
    return () => el.removeEventListener("wheel", handleWheel);
  }, [setHeaderHidden]);

  useEffect(() => {
    const el = gamesScrollRef.current;
    if (!el) return;
    const ro = new ResizeObserver(([entry]) =>
      setContainerWidth(entry.contentRect.width)
    );
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    if (
      effectiveCategory === "classics" &&
      !classicsOnboardingTriggeredRef.current &&
      !hasDismissedClassicsOnboarding()
    ) {
      classicsOnboardingTriggeredRef.current = true;
      setShowClassicsOnboarding(true);
    }
  }, [effectiveCategory]);

  const handleCategoryChange = useCallback((next: LibraryCategory) => {
    setCategory(next);
    localStorage.setItem("library-category", next);
    if (next === "pc") {
      setSelectedPlatform(null);
    }
  }, []);

  const searchQuery = useAppSelector((state) => state.library.searchQuery);
  const deferredSearchQuery = useDeferredValue(searchQuery);
  const dispatch = useAppDispatch();
  const { t } = useTranslation(["library", "sidebar"]);

  const selectedCollectionId = searchParams.get("collection");

  const handleCollectionSelect = useCallback(
    (collectionId: string | null) => {
      const params = new URLSearchParams(searchParams);

      if (collectionId) {
        params.set("collection", collectionId);
      } else {
        params.delete("collection");
      }

      setSearchParams(params, { replace: true });
    },
    [searchParams, setSearchParams]
  );

  const handleViewModeChange = useCallback((mode: ViewMode) => {
    setViewMode(mode);
    localStorage.setItem("library-view-mode", mode);
  }, []);

  const handleSortChange = useCallback((nextSortBy: SortOption) => {
    setSortBy(nextSortBy);
    localStorage.setItem("library-sort-by", nextSortBy);
  }, []);

  useEffect(() => {
    dispatch(setHeaderTitle(t("library")));

    const unsubscribe = window.electron.onLibraryBatchComplete(() => {
      updateLibrary();
      void loadCollections();
    });

    const unsubscribeClassicsImport = window.electron.onClassicsImportStatus(
      (importing) => setIsImportingClassics(importing)
    );

    void window.electron
      .getClassicsImportStatus()
      .then((importing) => setIsImportingClassics(importing));

    window.electron.refreshLibraryAssets().finally(() => {
      const collectionsPromise = hasLoadedCollections
        ? Promise.resolve([])
        : loadCollections();

      void Promise.all([updateLibrary(), collectionsPromise]);
    });

    return () => {
      unsubscribe();
      unsubscribeClassicsImport();
    };
  }, [dispatch, t, updateLibrary, loadCollections, hasLoadedCollections]);

  const handleOpenContextMenu = useCallback(
    (game: LibraryGame, position: { x: number; y: number }) => {
      setGameContextMenu({ game, visible: true, position });
    },
    []
  );

  const handleCloseContextMenu = useCallback(() => {
    setGameContextMenu((prev) => ({ ...prev, visible: false }));
  }, []);

  useEffect(() => {
    const handlePinToggled = () => {
      void updateLibrary();
    };

    window.addEventListener("hydra:game-pin-toggled", handlePinToggled);
    return () => {
      window.removeEventListener("hydra:game-pin-toggled", handlePinToggled);
    };
  }, [updateLibrary]);

  const handleCreateCollectionButtonClick = useCallback(() => {
    if (!userDetails) {
      window.electron.openAuthWindow(AuthPage.SignIn);
      return;
    }

    setShowCreateCollectionModal(true);
  }, [userDetails]);

  useEffect(() => {
    if (!selectedCollectionId) return;
    if (!hasLoadedCollections) return;

    if (selectedCollectionId === FAVORITES_COLLECTION_ID) return;

    const hasCollection = collections.some(
      (collection) => collection.id === selectedCollectionId
    );

    if (!hasCollection) {
      handleCollectionSelect(null);
    }
  }, [
    collections,
    selectedCollectionId,
    handleCollectionSelect,
    hasLoadedCollections,
  ]);

  const sortedLibrary = useMemo(
    () => sortLibraryGames(library, sortBy),
    [library, sortBy]
  );

  const filteredLibrary = useMemo(() => {
    let filtered = sortedLibrary;

    if (selectedCollectionId) {
      if (selectedCollectionId === FAVORITES_COLLECTION_ID) {
        filtered = filtered.filter((game) => game.favorite);
      } else {
        filtered = filtered.filter((game) =>
          getGameCollectionIds(game).includes(selectedCollectionId)
        );
      }
    }

    if (effectiveCategory === "pc") {
      filtered = filtered.filter((game) => game.shop !== "launchbox");
    } else if (effectiveCategory === "classics") {
      filtered = filtered.filter((game) => game.shop === "launchbox");
      if (selectedPlatform) {
        filtered = filtered.filter(
          (game) => game.platform === selectedPlatform
        );
      }
    } else if (selectedPlatform) {
      filtered = filtered.filter(
        (game) =>
          game.shop !== "launchbox" || game.platform === selectedPlatform
      );
    }

    const queryLower = removeDiacritics(deferredSearchQuery).toLowerCase();

    if (!queryLower.trim()) return filtered;

    return filtered.filter((game) => {
      const titleLower = removeDiacritics(game.title ?? "").toLowerCase();
      let queryIndex = 0;

      for (
        let i = 0;
        i < titleLower.length && queryIndex < queryLower.length;
        i++
      ) {
        if (titleLower[i] === queryLower[queryIndex]) {
          queryIndex++;
        }
      }

      return queryIndex === queryLower.length;
    });
  }, [
    sortedLibrary,
    deferredSearchQuery,
    selectedCollectionId,
    effectiveCategory,
    selectedPlatform,
  ]);

  const uniquePlatforms = useMemo(() => {
    const set = new Set<string>();
    for (const game of library) {
      if (game.shop === "launchbox" && game.platform) {
        set.add(game.platform);
      }
    }
    return Array.from(set).sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: "base" })
    );
  }, [library]);

  const favoritesCount = useMemo(() => {
    return library.filter((game) => game.favorite).length;
  }, [library]);

  const libraryCollections = useMemo<GameCollection[]>(() => {
    return [
      {
        id: FAVORITES_COLLECTION_ID,
        name: t("favorites"),
        gamesCount: favoritesCount,
      },
      ...collections,
    ];
  }, [collections, favoritesCount, t]);

  const columnsCount = useMemo(
    () => getColumnsCount(containerWidth, viewMode),
    [containerWidth, viewMode]
  );

  const rows = useMemo(() => {
    const result: LibraryGame[][] = [];
    for (let i = 0; i < filteredLibrary.length; i += columnsCount) {
      result.push(filteredLibrary.slice(i, i + columnsCount));
    }
    return result;
  }, [filteredLibrary, columnsCount]);

  const estimatedRowHeight = useMemo(() => {
    if (viewMode === "large") return LARGE_CARD_ESTIMATED_HEIGHT + GAP;
    const itemWidth =
      containerWidth > 0
        ? (containerWidth - GAP * (columnsCount - 1)) / columnsCount
        : FALLBACK_ITEM_WIDTH;
    return Math.round((itemWidth * 3) / 2) + GAP;
  }, [viewMode, containerWidth, columnsCount]);

  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => gamesScrollRef.current,
    estimateSize: () => estimatedRowHeight,
    overscan: 3,
  });

  useEffect(() => {
    rowVirtualizer.measure();
  }, [rowVirtualizer, estimatedRowHeight]);

  useEffect(() => {
    gamesScrollRef.current?.scrollTo({ top: 0 });
    setHeaderHidden(false);
  }, [
    effectiveCategory,
    selectedPlatform,
    sortBy,
    selectedCollectionId,
    setHeaderHidden,
  ]);

  const hasGames = library.length > 0;
  const hasNoFilteredGames = filteredLibrary.length === 0;
  const isFavoritesCollectionSelected =
    selectedCollectionId === FAVORITES_COLLECTION_ID;
  const shouldShowFavoritesEmptyState =
    hasGames && isFavoritesCollectionSelected && hasNoFilteredGames;
  const shouldShowCollectionEmptyState =
    hasGames &&
    !shouldShowFavoritesEmptyState &&
    Boolean(selectedCollectionId) &&
    !isFavoritesCollectionSelected &&
    hasNoFilteredGames;
  const shouldShowClassicsImporting =
    effectiveCategory === "classics" &&
    isImportingClassics &&
    hasNoFilteredGames;
  const shouldShowNoResultsEmptyState =
    hasGames &&
    hasNoFilteredGames &&
    !shouldShowFavoritesEmptyState &&
    !shouldShowCollectionEmptyState &&
    !shouldShowClassicsImporting;

  return (
    <section
      className={`library__content${hasGames && isHeaderHidden ? " library__content--header-hidden" : ""}`}
    >
      {hasGames && (
        <div
          className={`library__page-header${isHeaderHidden ? " library__page-header--hidden" : ""}`}
        >
          <div className="library__controls-row">
            <div className="library__controls-left">
              <CategoryFilter
                category={effectiveCategory}
                onCategoryChange={handleCategoryChange}
              />
              <CollectionsFilter
                collections={libraryCollections}
                selectedCollectionId={selectedCollectionId}
                favoritesCollectionId={FAVORITES_COLLECTION_ID}
                onSelect={handleCollectionSelect}
                onCreate={handleCreateCollectionButtonClick}
                onCollectionContextMenu={openCollectionContextMenu}
              />
            </div>

            <div className="library__controls-right">
              <FilterOptions sortBy={sortBy} onSortChange={handleSortChange} />
              {effectiveCategory !== "pc" && (
                <PlatformFilter
                  platform={selectedPlatform}
                  platforms={uniquePlatforms}
                  onPlatformChange={setSelectedPlatform}
                />
              )}
              <ViewOptions
                viewMode={viewMode}
                onViewModeChange={handleViewModeChange}
              />
            </div>
          </div>
        </div>
      )}

      {!hasGames && !shouldShowClassicsImporting && (
        <div className="library__no-games">
          <div className="library__telescope-icon">
            <TelescopeIcon size={24} />
          </div>
          <h2>{t("no_games_title")}</h2>
          <p>{t("no_games_description")}</p>
        </div>
      )}

      {shouldShowClassicsImporting && (
        <div className="library__empty">
          <div className="library__icon-container library__icon-container--spinning">
            <SyncIcon size={24} />
          </div>
          <h2>{t("importing_classics_title")}</h2>
          <p>{t("importing_classics_description")}</p>
        </div>
      )}

      {shouldShowFavoritesEmptyState && (
        <div className="library__empty">
          <div className="library__icon-container">
            <HeartIcon size={24} />
          </div>
          <h2>{t("empty_favorites_title")}</h2>
          <p>{t("empty_favorites_description")}</p>
        </div>
      )}

      {shouldShowCollectionEmptyState && (
        <div className="library__empty">
          <div className="library__icon-container">
            <FileDirectoryIcon size={24} />
          </div>
          <h2>{t("empty_collection_title")}</h2>
          <p>{t("empty_collection_description")}</p>
        </div>
      )}

      {shouldShowNoResultsEmptyState && (
        <div className="library__empty">
          <div className="library__icon-container">
            <SearchIcon size={24} />
          </div>
          <h2>{t("no_results")}</h2>
          <p>{t("no_results_description")}</p>
        </div>
      )}

      <div
        className="library__games-scroll"
        ref={gamesScrollRef}
        onScroll={handleGamesScroll}
      >
        <div
          className={`library__scroll-shadow${isGamesScrolled && isHeaderHidden ? " library__scroll-shadow--visible" : ""}`}
        />
        {hasGames &&
          !shouldShowFavoritesEmptyState &&
          !shouldShowCollectionEmptyState &&
          !shouldShowClassicsImporting &&
          !shouldShowNoResultsEmptyState && (
            <div
              style={{
                height: `${rowVirtualizer.getTotalSize()}px`,
                position: "relative",
              }}
            >
              {rowVirtualizer.getVirtualItems().map((virtualRow) => (
                <div
                  key={virtualRow.key}
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    right: GAP,
                    transform: `translateY(${virtualRow.start}px)`,
                    display: "grid",
                    gridTemplateColumns: `repeat(${columnsCount}, 1fr)`,
                    gap: `${GAP}px`,
                  }}
                >
                  {rows[virtualRow.index].map((game) =>
                    viewMode === "large" ? (
                      <LibraryGameCardLarge
                        key={`${game.shop}-${game.objectId}`}
                        game={game}
                        onContextMenu={handleOpenContextMenu}
                      />
                    ) : (
                      <LibraryGameCard
                        key={`${game.shop}-${game.objectId}`}
                        game={game}
                        onContextMenu={handleOpenContextMenu}
                      />
                    )
                  )}
                </div>
              ))}
            </div>
          )}
      </div>

      {gameContextMenu.game && (
        <GameContextMenu
          game={gameContextMenu.game}
          visible={gameContextMenu.visible}
          position={gameContextMenu.position}
          onClose={handleCloseContextMenu}
          onCollectionContextMenu={openCollectionContextMenu}
        />
      )}

      <CreateCollectionModal
        visible={showCreateCollectionModal}
        onClose={() => setShowCreateCollectionModal(false)}
      />

      <ClassicsOnboardingModal
        visible={showClassicsOnboarding}
        onClose={() => setShowClassicsOnboarding(false)}
      />
    </section>
  );
}
