import { createContext, useCallback, useEffect, useRef, useState } from "react";

import { setHeaderTitle } from "@renderer/features";
import { levelDBService } from "@renderer/services/leveldb.service";
import { ensureArray } from "@renderer/helpers";
import { orderBy } from "lodash-es";
import {
  useAppDispatch,
  useAppSelector,
  useDownload,
  useUserDetails,
} from "@renderer/hooks";

import type {
  DownloadSource,
  GameRepack,
  GameShop,
  GameStats,
  LibraryGame,
  ShopDetailsWithAssets,
  UserAchievement,
} from "@types";

import { useTranslation } from "react-i18next";
import { useLocation } from "react-router-dom";
import {
  GameDetailsContext,
  GameOptionsCategoryId,
} from "./game-details.context.types";
import {
  applyHosterAvailability,
  fetchHosterAvailability,
  getGameExecutableFilters,
  SteamContentDescriptor,
} from "@shared";

export const gameDetailsContext = createContext<GameDetailsContext>({
  game: null,
  shopDetails: null,
  repacks: [],
  shop: "steam",
  gameTitle: "",
  isGameRunning: false,
  isLoading: false,
  objectId: undefined,
  showRepacksModal: false,
  showGameOptionsModal: false,
  gameOptionsInitialCategory: "general",
  stats: null,
  achievements: null,
  hasNSFWContentBlocked: false,
  lastDownloadedOption: null,
  isTransferring: false,
  transferProgress: 0,
  selectGameExecutable: async () => null,
  updateGame: async () => {},
  refreshGameDetails: async () => {},
  setShowGameOptionsModal: () => {},
  setGameOptionsInitialCategory: () => {},
  setShowRepacksModal: () => {},
  setHasNSFWContentBlocked: () => {},
  cancelTransfer: () => {},
});

const { Provider } = gameDetailsContext;
export const { Consumer: GameDetailsContextConsumer } = gameDetailsContext;

export interface GameDetailsContextProps {
  children: React.ReactNode;
  objectId: string;
  gameTitle: string;
  shop: GameShop;
}

export function GameDetailsContextProvider({
  children,
  objectId,
  gameTitle,
  shop,
}: Readonly<GameDetailsContextProps>) {
  const [shopDetails, setShopDetails] = useState<ShopDetailsWithAssets | null>(
    null
  );
  const [achievements, setAchievements] = useState<UserAchievement[] | null>(
    null
  );
  const [game, setGame] = useState<LibraryGame | null>(null);
  const [hasNSFWContentBlocked, setHasNSFWContentBlocked] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);
  const [isTransferring, setIsTransferring] = useState(false);
  const [transferProgress, setTransferProgress] = useState(0);

  const [stats, setStats] = useState<GameStats | null>(null);

  const [isLoading, setIsLoading] = useState(true);
  const [isGameRunning, setIsGameRunning] = useState(false);
  const [showRepacksModal, setShowRepacksModal] = useState(false);
  const [showGameOptionsModal, setShowGameOptionsModal] = useState(false);
  const [gameOptionsInitialCategory, setGameOptionsInitialCategory] =
    useState<GameOptionsCategoryId>("general");
  const [repacks, setRepacks] = useState<GameRepack[]>([]);

  const { t, i18n } = useTranslation("game_details");
  const location = useLocation();

  const dispatch = useAppDispatch();

  const { lastPacket } = useDownload();
  const { userDetails } = useUserDetails();

  const userPreferences = useAppSelector(
    (state) => state.userPreferences.value
  );

  const updateGame = useCallback(async () => {
    return window.electron
      .getGameByObjectId(shop, objectId)
      .then((result) => setGame(result));
  }, [shop, objectId]);

  const fetchGameDetails = useCallback(async () => {
    if (abortControllerRef.current) abortControllerRef.current.abort();
    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    const shopDetailsPromise = window.electron
      .getGameShopDetails(objectId, shop, i18n.language)
      .then((result) => {
        if (abortController.signal.aborted) return;

        setShopDetails(result);

        if (
          result?.content_descriptors.ids.includes(
            SteamContentDescriptor.AdultOnlySexualContent
          ) &&
          !userPreferences?.disableNsfwAlert
        ) {
          setHasNSFWContentBlocked(true);
        }

        if (result?.assets) {
          setIsLoading(false);
        }

        if (userDetails && shop !== "custom") {
          const useRetroAchievements =
            shop === "launchbox" &&
            Boolean(userPreferences?.retroAchievementsWebApiKey);

          if (useRetroAchievements) {
            globalThis.window.electron
              .getRetroAchievementsAchievements(
                objectId,
                shop,
                result?.retroAchievementsGameId ?? undefined
              )
              .then((achievements) => {
                if (abortController.signal.aborted) return;
                setAchievements(achievements ?? []);
              })
              .catch(() => {
                if (!abortController.signal.aborted) setAchievements([]);
              });
          } else {
            globalThis.window.electron
              .getUnlockedAchievements(objectId, shop)
              .then((achievements) => {
                if (abortController.signal.aborted) return;
                if (achievements) setAchievements(achievements);
              })
              .catch(() => void 0);
          }
        }
      });

    if (shop !== "custom") {
      window.electron.getGameStats(objectId, shop).then((result) => {
        if (abortController.signal.aborted) return;
        setStats(result);
      });
    }

    const assetsPromise = window.electron.getGameAssets(objectId, shop);

    Promise.all([shopDetailsPromise, assetsPromise])
      .then(([_, assets]) => {
        if (assets) {
          if (abortController.signal.aborted) return;
          setShopDetails((prev) => {
            if (!prev) return null;
            return {
              ...prev,
              assets,
            };
          });
        }
      })
      .finally(() => {
        if (abortController.signal.aborted) return;
        setIsLoading(false);
      });
  }, [
    i18n.language,
    objectId,
    shop,
    userDetails,
    userPreferences?.disableNsfwAlert,
    userPreferences?.retroAchievementsWebApiKey,
  ]);

  const refreshGameDetails = useCallback(async () => {
    await Promise.all([updateGame(), fetchGameDetails()]);
  }, [fetchGameDetails, updateGame]);

  const isGameDownloading =
    lastPacket?.gameId === game?.id && game?.download?.status === "active";

  useEffect(() => {
    updateGame();
  }, [updateGame, isGameDownloading, lastPacket?.gameId]);

  // Listen for transfer events
  useEffect(() => {
    const onTransferProgress = (
      _: unknown,
      shop: string,
      objectId: string,
      progress: number
    ) => {
      if (shop === game?.shop && objectId === game?.objectId) {
        setIsTransferring(progress >= 0 && progress < 1);
        setTransferProgress(progress);
      }
    };

    const onTransferComplete = (_: unknown, shop: string, objectId: string) => {
      if (shop === game?.shop && objectId === game?.objectId) {
        setIsTransferring(false);
        setTransferProgress(0);
        updateGame();
      }
    };

    const onTransferCancelled = (
      _: unknown,
      shop: string,
      objectId: string
    ) => {
      if (shop === game?.shop && objectId === game?.objectId) {
        setIsTransferring(false);
        setTransferProgress(0);
      }
    };

    const onTransferError = (_: unknown, shop: string, objectId: string) => {
      if (shop === game?.shop && objectId === game?.objectId) {
        setIsTransferring(false);
        setTransferProgress(0);
      }
    };

    window.electron.on("on-game-transfer-progress", onTransferProgress);
    window.electron.on("on-game-transfer-complete", onTransferComplete);
    window.electron.on("on-game-transfer-cancelled", onTransferCancelled);
    window.electron.on("on-game-transfer-error", onTransferError);

    return () => {
      window.electron.off("on-game-transfer-progress", onTransferProgress);
      window.electron.off("on-game-transfer-complete", onTransferComplete);
      window.electron.off("on-game-transfer-cancelled", onTransferCancelled);
      window.electron.off("on-game-transfer-error", onTransferError);
    };
  }, [game, updateGame]);

  useEffect(() => {
    fetchGameDetails().catch(() => {});
  }, [fetchGameDetails]);

  useEffect(() => {
    setShopDetails(null);
    setGame(null);
    setIsLoading(true);
    setIsGameRunning(false);
    setAchievements(null);
    setGameOptionsInitialCategory("general");
    dispatch(setHeaderTitle(gameTitle));
  }, [objectId, gameTitle, dispatch]);

  useEffect(() => {
    const state =
      (location && (location.state as Record<string, unknown>)) || {};
    if (state.openRepacks) {
      setShowRepacksModal(true);
      try {
        window.history.replaceState({}, document.title, location.pathname);
      } catch (e) {
        console.error(e);
      }
    }
  }, [location]);

  useEffect(() => {
    if (game?.title) {
      dispatch(setHeaderTitle(game.title));
    }
  }, [game?.title, dispatch]);

  useEffect(() => {
    const unsubscribe = window.electron.onGamesRunning((gamesIds) => {
      const updatedIsGameRunning =
        !!game?.id &&
        !!gamesIds.find((gameRunning) => gameRunning.id == game.id);

      if (isGameRunning != updatedIsGameRunning) {
        updateGame();
      }

      setIsGameRunning(updatedIsGameRunning);
    });

    return () => {
      unsubscribe();
    };
  }, [game?.id, isGameRunning, updateGame]);

  useEffect(() => {
    const unsubscribe = window.electron.onLibraryBatchComplete(() => {
      refreshGameDetails().catch(() => {});
    });

    return () => {
      unsubscribe();
    };
  }, [refreshGameDetails]);

  useEffect(() => {
    const handler = (ev: Event) => {
      try {
        const detail = (ev as CustomEvent).detail || {};
        if (detail.objectId && detail.objectId === objectId) {
          setShowRepacksModal(true);
        }
      } catch (e) {
        void e;
      }
    };

    window.addEventListener("hydra:openRepacks", handler as EventListener);

    return () => {
      window.removeEventListener("hydra:openRepacks", handler as EventListener);
    };
  }, [objectId]);

  useEffect(() => {
    const handler = (ev: Event) => {
      try {
        const detail = (ev as CustomEvent).detail || {};
        if (detail.objectId && detail.objectId === objectId) {
          setGameOptionsInitialCategory("general");
          setShowGameOptionsModal(true);
        }
      } catch (e) {
        void e;
      }
    };

    window.addEventListener("hydra:openGameOptions", handler as EventListener);

    return () => {
      window.removeEventListener(
        "hydra:openGameOptions",
        handler as EventListener
      );
    };
  }, [objectId]);

  useEffect(() => {
    const state =
      (location && (location.state as Record<string, unknown>)) || {};
    if (state.openGameOptions) {
      setGameOptionsInitialCategory("general");
      setShowGameOptionsModal(true);

      try {
        window.history.replaceState({}, document.title, location.pathname);
      } catch (_e) {
        void _e;
      }
    }
  }, [location]);

  useEffect(() => {
    const unsubscribe = window.electron.onUpdateAchievements(
      objectId,
      shop,
      (achievements) => {
        if (!userDetails) return;
        setAchievements(achievements);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [objectId, shop, userDetails]);

  useEffect(() => {
    if (shop === "custom") return;

    let cancelled = false;

    const fetchDownloadSources = async () => {
      try {
        const sourcesRaw = (await levelDBService.values(
          "downloadSources"
        )) as DownloadSource[];
        const sources = orderBy(sourcesRaw, "createdAt", "desc");

        const params = {
          take: 100,
          skip: 0,
          downloadSourceIds: sources.map((source) => source.id),
        };

        const downloads = await window.electron.hydraApi.get<GameRepack[]>(
          `/games/${shop}/${objectId}/download-sources`,
          {
            params,
            needsAuth: false,
          }
        );

        if (cancelled) return;

        const downloadOptions = ensureArray<GameRepack>(
          downloads,
          `/games/${shop}/${objectId}/download-sources`
        );

        setRepacks(downloadOptions);

        const results = await fetchHosterAvailability(
          downloadOptions,
          (url, data) =>
            window.electron.hydraApi.post(url, { data, needsAuth: false })
        );

        if (cancelled || results.length === 0) return;

        setRepacks(applyHosterAvailability(downloadOptions, results));
      } catch (error) {
        console.error("Failed to fetch download sources:", error);
      }
    };

    fetchDownloadSources();

    return () => {
      cancelled = true;
    };
  }, [shop, objectId]);

  const getDownloadsPath = async () => {
    if (userPreferences?.downloadsPath) return userPreferences.downloadsPath;
    return window.electron.getDefaultDownloadsPath();
  };

  const selectGameExecutable = async () => {
    const downloadsPath = await getDownloadsPath();

    const filters = getGameExecutableFilters(
      globalThis.window.electron.platform,
      {
        executable: t("game_executable"),
        allFiles: t("all_files"),
      }
    );

    return window.electron
      .showOpenDialog({
        properties: ["openFile"],
        defaultPath: downloadsPath,
        filters,
      })
      .then(({ filePaths }) => {
        if (filePaths && filePaths.length > 0) {
          return filePaths[0];
        }

        return null;
      });
  };

  // Handlers for cancel
  const cancelTransfer = () => {
    window.electron.cancelGameTransfer?.(shop, objectId);
    setIsTransferring(false);
    setTransferProgress(0);
  };

  return (
    <Provider
      value={{
        game,
        shopDetails,
        shop,
        repacks,
        gameTitle,
        isGameRunning,
        isLoading,
        objectId,
        showGameOptionsModal,
        gameOptionsInitialCategory,
        showRepacksModal,
        stats,
        achievements,
        hasNSFWContentBlocked,
        lastDownloadedOption: null,
        isTransferring,
        transferProgress,
        setHasNSFWContentBlocked,
        selectGameExecutable,
        updateGame,
        refreshGameDetails,
        setShowRepacksModal,
        setShowGameOptionsModal,
        setGameOptionsInitialCategory,
        cancelTransfer,
      }}
    >
      {children}
    </Provider>
  );
}
