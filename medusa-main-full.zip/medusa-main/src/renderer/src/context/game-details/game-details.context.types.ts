import type {
  GameRepack,
  GameShop,
  GameStats,
  LibraryGame,
  ShopDetailsWithAssets,
  UserAchievement,
} from "@types";

export type GameOptionsCategoryId =
  | "general"
  | "locations"
  | "assets"
  | "hydra_cloud"
  | "hydra_cloud_legacy"
  | "compatibility"
  | "downloads"
  | "danger_zone";

export interface GameDetailsContext {
  game: LibraryGame | null;
  shopDetails: ShopDetailsWithAssets | null;
  repacks: GameRepack[];
  shop: GameShop;
  gameTitle: string;
  isGameRunning: boolean;
  isLoading: boolean;
  objectId: string | undefined;
  showRepacksModal: boolean;
  showGameOptionsModal: boolean;
  gameOptionsInitialCategory: GameOptionsCategoryId;
  stats: GameStats | null;
  achievements: UserAchievement[] | null;
  hasNSFWContentBlocked: boolean;
  lastDownloadedOption: GameRepack | null;
  isTransferring: boolean;
  transferProgress: number;
  selectGameExecutable: () => Promise<string | null>;
  updateGame: () => Promise<void>;
  refreshGameDetails: () => Promise<void>;
  setShowRepacksModal: React.Dispatch<React.SetStateAction<boolean>>;
  setShowGameOptionsModal: React.Dispatch<React.SetStateAction<boolean>>;
  setGameOptionsInitialCategory: React.Dispatch<
    React.SetStateAction<GameOptionsCategoryId>
  >;
  setHasNSFWContentBlocked: React.Dispatch<React.SetStateAction<boolean>>;
  cancelTransfer: () => void;
}
