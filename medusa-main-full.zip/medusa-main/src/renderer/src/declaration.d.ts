import type { AuthPage } from "@shared";
import type {
  AppUpdaterEvent,
  GameShop,
  Steam250Game,
  DownloadProgress,
  SeedingStatus,
  UserPreferences,
  StartGameDownloadPayload,
  RealDebridUser,
  PremiumizeUser,
  AllDebridUser,
  UserProfile,
  UpdateProfileRequest,
  GameStats,
  UserDetails,
  FriendRequestSync,
  FriendPresenceSync,
  NotificationSync,
  GameArtifact,
  LudusaviBackup,
  UserAchievement,
  ComparedAchievements,
  LibraryGame,
  GameRunning,
  TorBoxUser,
  Theme,
  Auth,
  ShortcutLocation,
  Ps2MemcardScanInput,
  Ps2MemcardScanProgress,
  Ps2MemoryCardSaveRecord,
  Ps2ExportResult,
  ShopAssets,
  ShopDetailsWithAssets,
  AchievementCustomNotificationPosition,
  AchievementNotificationInfo,
  AchievementNotificationRequest,
  Game,
  DiskUsage,
  NetworkInterface,
  DownloadSource,
  LocalNotification,
  ProtonVersion,
  CreateSteamShortcutOptions,
  TorrentFilesResponse,
  DownloadLayoutState,
  EmulatorConfig,
  EmulatorConfigMap,
  EmulatorSystem,
  EmulationBackupProgress,
  EmulatorBinary,
  EmulatorInstallProgress,
  EmulatorInstallResult,
  ResolvedInstallOption,
  DetectedRom,
  RetroArchConfig,
  RetroArchCoreName,
  RetroArchPlatform,
  RetroArchCoreInstallProgress,
  RetroArchCoreInstallResult,
  RetroArchExecutablePreview,
  RetroArchInstallOption,
  RetroArchInstallProgress,
  RetroArchInstallResult,
  EmulationCloudSave,
  EmulationSavePlatform,
  MemcardFormatState,
  MemcardRestoreResult,
  MemcardRestoreTarget,
  ArtworkAssetType,
  ArtworkKind,
  ArtworkPage,
  GameArtworkSelection,
  CloudSaveAutomaticSyncModeChangedEvent,
  CloudSaveAutomaticSyncEvent,
  CloudSaveConflictResolution,
  CloudSaveOverview,
  CloudSaveV2FileDetails,
  CloudSaveSyncProgressPayload,
  SyncCloudSaveOnGamePageResult,
  SyncGameCloudSaveResult,
  SelectCloudSaveCustomPathResult,
  CloudSaveCustomPathApproval,
  CloudSaveModalSyncResult,
  SelectCloudSaveCustomPathApprovalResult,
  ConfirmCloudSaveCustomPathApprovalResult,
  ConfirmCloudSaveCustomPathRebindApprovalResult,
  LegacySaveExportProgress,
  LegacySaveExportResult,
} from "@types";
import type { AxiosProgressEvent } from "axios";

export interface DriveInfo {
  root: string;
  label: string;
  free: number;
  total: number;
}

declare global {
  declare module "*.svg" {
    const content: React.FunctionComponent<React.SVGAttributes<SVGElement>>;
    export default content;
  }

  type FileExplorerEntry = {
    name: string;
    path: string;
    isDirectory: boolean;
    isFile: boolean;
    extension: string;
    size: number;
  };

  type FileExplorerPathInfo = {
    exists: boolean;
    isDirectory: boolean;
    isFile: boolean;
  };

  interface Electron {
    onCloudSaveAutomaticSyncModeChanged: (
      callback: (event: CloudSaveAutomaticSyncModeChangedEvent) => void
    ) => () => void;
    onCloudSaveAutomaticSync: (
      callback: (event: CloudSaveAutomaticSyncEvent) => void
    ) => () => void;
    getCloudSaveOverview: (
      objectId: string,
      shop: GameShop
    ) => Promise<CloudSaveOverview>;
    getCloudSaveV2FileDetails: (
      objectId: string,
      shop: GameShop
    ) => Promise<CloudSaveV2FileDetails>;
    deleteGameCloudSaveData: (
      objectId: string,
      shop: GameShop
    ) => Promise<void>;
    selectCloudSaveCustomPath: (
      objectId: string,
      shop: GameShop
    ) => Promise<SelectCloudSaveCustomPathResult>;
    createCloudSaveCustomPathRebindApproval: (
      objectId: string,
      shop: GameShop,
      rawPath: string
    ) => Promise<CloudSaveCustomPathApproval>;
    confirmCloudSaveCustomPathRebindApproval: (
      approvalId: string,
      objectId: string,
      shop: GameShop
    ) => Promise<ConfirmCloudSaveCustomPathRebindApprovalResult>;
    getPendingCloudSaveCustomPathApproval: (
      objectId: string,
      shop: GameShop
    ) => Promise<CloudSaveCustomPathApproval | null>;
    selectCloudSaveCustomPathApproval: (
      approvalId: string,
      selectedPath?: string
    ) => Promise<SelectCloudSaveCustomPathApprovalResult>;
    confirmCloudSaveCustomPathApproval: (
      approvalId: string
    ) => Promise<ConfirmCloudSaveCustomPathApprovalResult>;
    dismissCloudSaveCustomPathApproval: (approvalId: string) => Promise<void>;
    removeCloudSaveCustomPath: (
      objectId: string,
      shop: GameShop,
      rawPath: string
    ) => Promise<void>;
    setCloudSaveAutomaticSyncEnabled: (
      objectId: string,
      shop: GameShop,
      enabled: boolean
    ) => Promise<boolean>;
    syncCloudSaveOnGamePage: (
      objectId: string,
      shop: GameShop
    ) => Promise<SyncCloudSaveOnGamePageResult>;
    syncGameCloudSave: (
      objectId: string,
      shop: GameShop,
      onProgress?: (progress: CloudSaveSyncProgressPayload) => void
    ) => Promise<SyncGameCloudSaveResult>;
    syncGameCloudSaveFromModal: (
      objectId: string,
      shop: GameShop,
      approvalId: string | null,
      onProgress?: (progress: CloudSaveSyncProgressPayload) => void
    ) => Promise<CloudSaveModalSyncResult>;
    syncCloudSaveAfterCustomPathRebind: (
      objectId: string,
      shop: GameShop,
      rawPath: string,
      onProgress?: (progress: CloudSaveSyncProgressPayload) => void
    ) => Promise<SyncGameCloudSaveResult>;
    resolveCloudSaveConflict: (
      objectId: string,
      shop: GameShop,
      resolution: CloudSaveConflictResolution,
      onProgress?: (progress: CloudSaveSyncProgressPayload) => void
    ) => Promise<SyncGameCloudSaveResult>;
    /* Torrenting */
    startGameDownload: (
      payload: StartGameDownloadPayload
    ) => Promise<{ ok: boolean; error?: string }>;
    addGameToQueue: (
      payload: StartGameDownloadPayload
    ) => Promise<{ ok: boolean; error?: string }>;
    cancelGameDownload: (shop: GameShop, objectId: string) => Promise<void>;
    pauseGameDownload: (shop: GameShop, objectId: string) => Promise<void>;
    resumeGameDownload: (
      shop: GameShop,
      objectId: string,
      strategy?: "interruptActive" | "queueIfActive"
    ) => Promise<void>;
    pauseGameSeed: (shop: GameShop, objectId: string) => Promise<void>;
    resumeGameSeed: (shop: GameShop, objectId: string) => Promise<void>;
    saveGlobalTrackers: (
      manual: string[],
      url: string | null,
      appendManual: boolean,
      appendUrl: boolean
    ) => Promise<void>;
    updateDownloadQueuePosition: (
      shop: GameShop,
      objectId: string,
      direction: "up" | "down"
    ) => Promise<boolean>;
    setDownloadQueuePosition: (
      shop: GameShop,
      objectId: string,
      targetIndex: number
    ) => Promise<boolean>;
    setPausedDownloadPosition: (
      shop: GameShop,
      objectId: string,
      targetIndex: number
    ) => Promise<boolean>;
    moveDownloadPlacement: (
      shop: GameShop,
      objectId: string,
      targetArea: "hero" | "queue" | "paused",
      targetIndex?: number
    ) => Promise<boolean>;
    getDownloadLayoutState: () => Promise<DownloadLayoutState>;
    onDownloadProgress: (
      cb: (value: DownloadProgress | null) => void
    ) => () => Electron.IpcRenderer;
    onSeedingStatus: (
      cb: (value: SeedingStatus[]) => void
    ) => () => Electron.IpcRenderer;
    onHardDelete: (cb: () => void) => () => Electron.IpcRenderer;
    getTorrentFiles: (
      magnet: string
    ) => Promise<
      { ok: true; data: TorrentFilesResponse } | { ok: false; error: string }
    >;

    /* Catalogue */
    getGameShopDetails: (
      objectId: string,
      shop: GameShop,
      language: string
    ) => Promise<ShopDetailsWithAssets | null>;
    getRandomGame: () => Promise<Steam250Game>;
    getGameStats: (objectId: string, shop: GameShop) => Promise<GameStats>;
    getGameAssets: (
      objectId: string,
      shop: GameShop,
      options?: { forceFresh?: boolean }
    ) => Promise<ShopAssets | null>;
    onUpdateAchievements: (
      objectId: string,
      shop: GameShop,
      cb: (achievements: UserAchievement[]) => void
    ) => () => Electron.IpcRenderer;

    /* Library */
    toggleAutomaticCloudSync: (
      shop: GameShop,
      objectId: string,
      automaticCloudSync: boolean
    ) => Promise<void>;
    toggleGameMangohud: (
      shop: GameShop,
      objectId: string,
      autoRunMangohud: boolean
    ) => Promise<void>;
    toggleGameGamemode: (
      shop: GameShop,
      objectId: string,
      autoRunGamemode: boolean
    ) => Promise<void>;
    isGamemodeAvailable: () => Promise<boolean>;
    isMangohudAvailable: () => Promise<boolean>;
    isWinetricksAvailable: () => Promise<boolean>;
    addGameToLibrary: (
      shop: GameShop,
      objectId: string,
      title: string,
      platform?: string | null
    ) => Promise<void>;
    addCustomGameToLibrary: (
      title: string,
      executablePath: string,
      iconUrl?: string,
      logoImageUrl?: string,
      libraryHeroImageUrl?: string
    ) => Promise<Game>;
    updateCustomGame: (params: {
      shop: GameShop;
      objectId: string;
      title: string;
      iconUrl?: string;
      logoImageUrl?: string;
      libraryHeroImageUrl?: string;
      customCoverImageUrl?: string | null;
      originalIconPath?: string;
      originalLogoPath?: string;
      originalHeroPath?: string;
      customOriginalCoverPath?: string;
    }) => Promise<Game>;
    copyCustomGameAsset: (
      sourcePath: string,
      assetType: "icon" | "logo" | "hero" | "grid"
    ) => Promise<string>;
    downloadGameArtwork: (artworkUrl: string) => Promise<string | null>;
    cleanupUnusedAssets: () => Promise<{
      deletedCount: number;
      errors: string[];
    }>;
    updateGameCustomAssets: (params: {
      shop: GameShop;
      objectId: string;
      title: string;
      customIconUrl?: string | null;
      customLogoImageUrl?: string | null;
      customHeroImageUrl?: string | null;
      customCoverImageUrl?: string | null;
      customOriginalIconPath?: string | null;
      customOriginalLogoPath?: string | null;
      customOriginalHeroPath?: string | null;
      customOriginalCoverPath?: string | null;
      customArtworkIds?: Partial<Record<ArtworkAssetType, number | null>>;
      clearArtworkTypes?: ArtworkAssetType[];
    }) => Promise<Game>;
    getGameArtwork: (
      shop: GameShop,
      objectId: string,
      kind: ArtworkKind,
      page?: number
    ) => Promise<ArtworkPage | null>;
    getCoverPoster: (url: string) => Promise<string | null>;
    getGameArtworkSelection: (
      shop: GameShop,
      objectId: string
    ) => Promise<GameArtworkSelection | null>;
    setGameArtworkSelection: (params: {
      shop: GameShop;
      objectId: string;
      type: ArtworkAssetType;
      url?: string;
      artworkId?: number;
      clear?: boolean;
    }) => Promise<GameArtworkSelection | null>;
    createGameShortcut: (
      shop: GameShop,
      objectId: string,
      location: ShortcutLocation
    ) => Promise<boolean>;
    updateExecutablePath: (
      shop: GameShop,
      objectId: string,
      executablePath: string | null
    ) => Promise<void>;
    updateTrackingExecutablePaths: (
      shop: GameShop,
      objectId: string,
      trackingExecutablePaths: string[]
    ) => Promise<void>;
    addGameToFavorites: (shop: GameShop, objectId: string) => Promise<void>;
    removeGameFromFavorites: (
      shop: GameShop,
      objectId: string
    ) => Promise<void>;
    assignGameToCollection: (
      shop: GameShop,
      objectId: string,
      collectionIds: string[]
    ) => Promise<void>;
    clearNewDownloadOptions: (
      shop: GameShop,
      objectId: string
    ) => Promise<void>;
    toggleGamePin: (
      shop: GameShop,
      objectId: string,
      pinned: boolean
    ) => Promise<void>;
    updateLaunchOptions: (
      shop: GameShop,
      objectId: string,
      launchOptions: string | null
    ) => Promise<void>;
    selectGameWinePrefix: (
      shop: GameShop,
      objectId: string,
      winePrefixPath: string | null
    ) => Promise<void>;
    selectGameProtonPath: (
      shop: GameShop,
      objectId: string,
      protonPath: string | null
    ) => Promise<void>;
    getInstalledProtonVersions: () => Promise<ProtonVersion[]>;
    getGameLaunchProtonVersion: (
      shop: GameShop,
      objectId: string
    ) => Promise<string | null>;
    verifyExecutablePathInUse: (executablePath: string) => Promise<Game>;
    getLibrary: () => Promise<LibraryGame[]>;
    refreshLibraryAssets: () => Promise<void>;
    openGameInstaller: (shop: GameShop, objectId: string) => Promise<boolean>;
    getGameInstallerActionType: (
      shop: GameShop,
      objectId: string
    ) => Promise<"install" | "open-folder">;
    openGameInstallerPath: (shop: GameShop, objectId: string) => Promise<void>;
    openGameWinetricks: (shop: GameShop, objectId: string) => Promise<boolean>;
    openGameExecutablePath: (shop: GameShop, objectId: string) => Promise<void>;
    getGameSaveFolder: (
      shop: GameShop,
      objectId: string
    ) => Promise<string | null>;
    openGameSaveFolder: (
      shop: GameShop,
      objectId: string,
      saveFolderPath: string
    ) => Promise<boolean>;
    openGame: (
      shop: GameShop,
      objectId: string,
      executablePath: string,
      launchOptions?: string | null
    ) => Promise<void>;
    openClassicsGame: (
      shop: GameShop,
      objectId: string,
      discPath?: string,
      force?: boolean
    ) => Promise<void>;
    updateClassicsDisc: (
      shop: GameShop,
      objectId: string,
      patch: {
        selectedDiscPath?: string | null;
        dontAskDiscSelection?: boolean;
        platform?: string | null;
        addDisc?: { path: string; label: string; fileName: string };
        removeDiscPath?: string;
      }
    ) => Promise<LibraryGame>;
    getEmulatorRomExtensions: (
      system: "ps1" | "ps2" | "ps3"
    ) => Promise<string[]>;
    closeGame: (shop: GameShop, objectId: string) => Promise<boolean>;
    removeGameFromLibrary: (shop: GameShop, objectId: string) => Promise<void>;
    removeGame: (shop: GameShop, objectId: string) => Promise<void>;
    deleteGameFolder: (shop: GameShop, objectId: string) => Promise<unknown>;
    getGameByObjectId: (
      shop: GameShop,
      objectId: string
    ) => Promise<LibraryGame | null>;
    getGamesRunning: () => Promise<
      Pick<GameRunning, "id" | "sessionDurationInMillis">[]
    >;
    onGamesRunning: (
      cb: (
        gamesRunning: Pick<GameRunning, "id" | "sessionDurationInMillis">[]
      ) => void
    ) => () => Electron.IpcRenderer;
    onLibraryBatchComplete: (cb: () => void) => () => Electron.IpcRenderer;
    onDownloadsUpdated: (cb: () => void) => () => Electron.IpcRenderer;
    onClassicsImportStatus: (
      cb: (importing: boolean) => void
    ) => () => Electron.IpcRenderer;
    getClassicsImportStatus: () => Promise<boolean>;
    getActiveClassicsImport: () => Promise<{
      requestId: string;
      system: EmulatorSystem;
      phase: "scanning" | "matching" | "done";
      processed: number;
      total: number;
      percent: number;
      currentFile: string | null;
      status: "matched" | "wrong_platform" | "unmatched" | null;
      discovered: number;
      matched: number;
      sizeBytes: number;
    } | null>;
    onClassicsImportProgress: (
      cb: (
        payload:
          | {
              type: "progress";
              requestId: string;
              system: EmulatorSystem;
              phase: "scanning" | "matching";
              processed: number;
              total: number;
              percent: number;
              currentFile: string | null;
              status: "matched" | "wrong_platform" | "unmatched" | null;
              discovered: number;
              matched: number;
              sizeBytes: number;
            }
          | {
              type: "done" | "cancelled";
              requestId: string;
              system: EmulatorSystem;
              fileCount: number;
              sizeBytes: number;
              matched: number;
              unmatched: number;
              unmatchedFiles: {
                name: string;
                reason: "wrong_platform" | "unmatched";
              }[];
            }
          | {
              type: "error";
              requestId: string;
              system: EmulatorSystem;
              message: string;
            }
      ) => void
    ) => () => Electron.IpcRenderer;
    resetGameAchievements: (shop: GameShop, objectId: string) => Promise<void>;
    changeGamePlayTime: (
      shop: GameShop,
      objectId: string,
      playtimeInSeconds: number
    ) => Promise<void>;
    resetGamePlayTime: (shop: GameShop, objectId: string) => Promise<void>;
    /* User preferences */
    authenticateRealDebrid: (apiToken: string) => Promise<RealDebridUser>;
    authenticatePremiumize: (apiToken: string) => Promise<PremiumizeUser>;
    authenticateAllDebrid: (apiToken: string) => Promise<AllDebridUser>;
    authenticateTorBox: (apiToken: string) => Promise<TorBoxUser>;
    getUserPreferences: () => Promise<UserPreferences | null>;
    updateUserPreferences: (
      preferences: Partial<UserPreferences>
    ) => Promise<void>;
    /* Emulators */
    getEmulatorConfigs: () => Promise<EmulatorConfigMap>;
    detectEmulators: () => Promise<EmulatorConfigMap>;
    detectEmulator: (system: EmulatorSystem) => Promise<EmulatorConfig>;
    previewEmulatorExecutable: (
      system: EmulatorSystem,
      executablePath?: string | null
    ) => Promise<{
      executablePath: string;
      detectedVersion: string | null;
    } | null>;
    setEmulatorExecutablePath: (
      system: EmulatorSystem,
      executablePath: string | null
    ) => Promise<EmulatorConfig>;
    setEmulatorBiosPath: (
      system: EmulatorSystem,
      biosPath: string | null
    ) => Promise<EmulatorConfig>;
    addRomFolder: (
      system: EmulatorSystem,
      folderPath: string,
      scanSubfolders: boolean,
      language?: string
    ) => Promise<EmulatorConfig>;
    removeRomFolder: (
      system: EmulatorSystem,
      folderId: string
    ) => Promise<EmulatorConfig>;
    listEmulatorRoms: (system: EmulatorSystem) => Promise<DetectedRom[]>;
    toggleRomFolderSubfolders: (
      system: EmulatorSystem,
      folderId: string,
      scanSubfolders: boolean
    ) => Promise<EmulatorConfig>;
    rescanEmulator: (
      system: EmulatorSystem,
      language?: string
    ) => Promise<EmulatorConfig>;
    checkPs3Firmware: (
      executablePath: string | null
    ) => Promise<{ installed: boolean }>;
    checkEmulatorBios: (
      system: EmulatorSystem,
      executablePath: string | null,
      manualBiosPath?: string | null
    ) => Promise<{ installed: boolean; detectedPath: string | null }>;
    getEmulatorInstallOptions: (
      binary: EmulatorBinary
    ) => Promise<ResolvedInstallOption[]>;
    installEmulator: (
      binary: EmulatorBinary,
      optionId: string
    ) => Promise<EmulatorInstallResult>;
    onEmulatorInstallProgress: (
      cb: (payload: EmulatorInstallProgress) => void
    ) => () => void;
    /* RetroArch */
    getRetroArchConfig: () => Promise<RetroArchConfig>;
    detectRetroArch: () => Promise<RetroArchConfig>;
    previewRetroArchExecutable: (
      executablePath?: string | null
    ) => Promise<RetroArchExecutablePreview | null>;
    setRetroArchExecutablePath: (
      executablePath: string | null
    ) => Promise<RetroArchConfig | null>;
    setRetroArchCoresDir: (coresDir: string | null) => Promise<RetroArchConfig>;
    getRetroArchInstallOptions: () => Promise<RetroArchInstallOption[]>;
    installRetroArch: (optionId: string) => Promise<RetroArchInstallResult>;
    installRetroArchCore: (
      core: RetroArchCoreName
    ) => Promise<RetroArchCoreInstallResult>;
    installAllRetroArchCores: () => Promise<RetroArchCoreInstallResult[]>;
    onRetroArchCoreInstallProgress: (
      cb: (payload: RetroArchCoreInstallProgress) => void
    ) => () => void;
    onRetroArchInstallProgress: (
      cb: (payload: RetroArchInstallProgress) => void
    ) => () => void;
    importRetroArchRoms: (
      folders: { path: string; scanSubfolders: boolean }[],
      language: string
    ) => Promise<{ requestId: string }>;
    cancelRetroArchImport: (requestId: string) => Promise<void>;
    rescanRetroArch: (language?: string) => Promise<RetroArchConfig>;
    listRetroArchRoms: () => Promise<
      (DetectedRom & { platform: RetroArchPlatform })[]
    >;
    getActiveRetroArchImport: () => Promise<{
      requestId: string;
      phase: "scanning" | "matching" | "done";
      processed: number;
      total: number;
      percent: number;
      currentFile: string | null;
      status: "matched" | "unmatched" | null;
      discovered: number;
      matched: number;
      sizeBytes: number;
    } | null>;
    onRetroArchImportProgress: (
      cb: (
        payload:
          | {
              type: "progress";
              requestId: string;
              phase: "scanning" | "matching";
              processed: number;
              total: number;
              percent: number;
              currentFile: string | null;
              status: "matched" | "unmatched" | null;
              discovered: number;
              matched: number;
              sizeBytes: number;
            }
          | {
              type: "done" | "cancelled";
              requestId: string;
              fileCount: number;
              sizeBytes: number;
              matched: number;
              unmatched: number;
              unmatchedFiles: { name: string; reason: "unmatched" }[];
            }
          | {
              type: "error";
              requestId: string;
              message: string;
            }
      ) => void
    ) => () => void;
    onRetroArchImportStatus: (cb: (importing: boolean) => void) => () => void;
    previewRetroArchRomFolder: (
      folderPath: string,
      scanSubfolders: boolean
    ) => Promise<{ fileCount: number }>;
    checkRetroArchExecutable: () => Promise<{ exists: boolean }>;
    removeRetroArch: () => Promise<RetroArchConfig>;
    addRetroArchRomFolder: (
      folderPath: string,
      scanSubfolders: boolean
    ) => Promise<RetroArchConfig>;
    changeRetroArchRomFolder: (
      folderId: string,
      newPath: string
    ) => Promise<RetroArchConfig>;
    removeRetroArchRomFolder: (folderId: string) => Promise<RetroArchConfig>;
    toggleRetroArchSubfolders: (
      folderId: string,
      scanSubfolders: boolean
    ) => Promise<RetroArchConfig>;
    startRomScan: (
      system: EmulatorSystem,
      folderPath: string,
      scanSubfolders: boolean
    ) => Promise<{ requestId: string }>;
    cancelRomScan: (requestId: string) => Promise<void>;
    getEmulatorRomPaths: (system: EmulatorSystem) => Promise<string[]>;
    addEmulatorRomPath: (
      system: EmulatorSystem,
      folderPath: string
    ) => Promise<boolean>;
    getRpcs3DefaultSources: () => Promise<{
      gamesDir: string | null;
      gamesYmlPath: string | null;
      gamesYmlEntries: { titleId: string; path: string }[];
    }>;
    removeEmulator: (system: EmulatorSystem) => Promise<EmulatorConfig>;
    checkEmulatorExecutable: (
      system: EmulatorSystem
    ) => Promise<{ exists: boolean }>;
    onRomScanProgress: (
      requestId: string,
      cb: (
        payload:
          | {
              type: "progress";
              processed: number;
              total: number;
              currentFile: string | null;
            }
          | { type: "done"; fileCount: number; sizeBytes: number }
          | { type: "cancelled"; fileCount: number; sizeBytes: number }
          | { type: "error"; message: string }
      ) => void
    ) => () => Electron.IpcRenderer;
    importLaunchboxRoms: (
      system: EmulatorSystem,
      folders: { path: string; scanSubfolders: boolean }[],
      language: string
    ) => Promise<{ requestId: string }>;
    cancelLaunchboxImport: (requestId: string) => Promise<void>;
    scanPs2Memcards: (
      input: Ps2MemcardScanInput
    ) => Promise<{ requestId: string }>;
    cancelPs2MemcardScan: (requestId: string) => Promise<void>;
    onPs2MemcardScanProgress: (
      requestId: string,
      cb: (payload: Ps2MemcardScanProgress) => void
    ) => () => Electron.IpcRenderer;
    listPs2MemcardSaves: () => Promise<Ps2MemoryCardSaveRecord[]>;
    forgetPs2MemcardSave: (
      cardFilePath: string,
      folderName: string
    ) => Promise<void>;
    forgetPs2MemcardCard: (cardFilePath: string) => Promise<void>;
    exportPs2Save: (
      cardFilePath: string,
      folderName: string,
      suggestedName: string
    ) => Promise<Ps2ExportResult>;
    scanPs1Memcards: (
      input: Ps2MemcardScanInput
    ) => Promise<{ requestId: string }>;
    cancelPs1MemcardScan: (requestId: string) => Promise<void>;
    onPs1MemcardScanProgress: (
      requestId: string,
      cb: (payload: Ps2MemcardScanProgress) => void
    ) => () => Electron.IpcRenderer;
    listPs1MemcardSaves: () => Promise<Ps2MemoryCardSaveRecord[]>;
    forgetPs1MemcardSave: (
      cardFilePath: string,
      identifier: string
    ) => Promise<void>;
    forgetPs1MemcardCard: (cardFilePath: string) => Promise<void>;
    exportPs1Save: (
      cardFilePath: string,
      identifier: string,
      suggestedName: string
    ) => Promise<Ps2ExportResult>;
    uploadEmulationSave: (
      platform: EmulationSavePlatform,
      cardFilePath: string,
      folderName: string
    ) => Promise<EmulationCloudSave>;
    uploadEmulationSavesForCard: (
      platform: EmulationSavePlatform,
      cardFilePath: string
    ) => Promise<{ uploaded: number; total: number }>;
    onEmulationBackupProgress: (
      cb: (payload: EmulationBackupProgress) => void
    ) => () => Electron.IpcRenderer;
    getActiveEmulationBackups: () => Promise<EmulationBackupProgress[]>;
    listEmulationSaves: (
      platform: EmulationSavePlatform,
      objectId?: string | null
    ) => Promise<EmulationCloudSave[]>;
    getMemcardRestoreTargets: (
      platform: EmulationSavePlatform
    ) => Promise<MemcardRestoreTarget[]>;
    inspectMemcard: (
      platform: EmulationSavePlatform,
      cardFilePath: string
    ) => Promise<MemcardFormatState>;
    restoreEmulationSave: (
      platform: EmulationSavePlatform,
      saveId: string,
      targetCardFilePath: string
    ) => Promise<MemcardRestoreResult>;
    deleteEmulationSave: (saveId: string) => Promise<void>;
    updateEmulationSaveLabel: (
      saveId: string,
      label: string
    ) => Promise<EmulationCloudSave>;
    onUserPreferencesUpdated: (
      cb: (preferences: UserPreferences | null) => void
    ) => () => Electron.IpcRenderer;
    autoLaunch: (autoLaunchProps: {
      enabled: boolean;
      minimized: boolean;
    }) => Promise<void>;
    extractGameDownload: (shop: GameShop, objectId: string) => Promise<boolean>;
    scanInstalledGames: (
      additionalDirectories?: string[],
      includeDefaultDirectories?: boolean,
      addGamesToLibrary?: boolean,
      requestId?: string
    ) => Promise<{
      linkedGames: {
        title: string;
        executablePath: string;
        iconUrl: string | null;
      }[];
      addedGames: {
        title: string;
        executablePath: string;
        iconUrl: string | null;
      }[];
      ambiguousMatches: {
        executablePath: string;
        choices: { objectId: string; title: string; iconUrl: string | null }[];
      }[];
      total: number;
    }>;
    cancelScanInstalledGames: (requestId: string) => Promise<void>;
    addScannedGame: (
      objectId: string,
      executablePath: string
    ) => Promise<{
      title: string;
      executablePath: string;
      iconUrl: string | null;
    } | null>;
    onExtractionComplete: (
      cb: (shop: GameShop, objectId: string) => void
    ) => () => Electron.IpcRenderer;
    onExtractionProgress: (
      cb: (shop: GameShop, objectId: string, progress: number) => void
    ) => () => Electron.IpcRenderer;
    onExtractionFailed: (
      cb: (shop: GameShop, objectId: string) => void
    ) => () => Electron.IpcRenderer;
    onDownloadHalted: (
      cb: (gameTitle: string) => void
    ) => () => Electron.IpcRenderer;
    onArchiveDeletionPrompt: (
      cb: (archivePaths: string[]) => void
    ) => () => Electron.IpcRenderer;
    deleteArchive: (filePath: string) => Promise<boolean>;
    getDefaultWinePrefixSelectionPath: () => Promise<string | null>;
    createSteamShortcut: (
      shop: GameShop,
      objectId: string,
      options?: CreateSteamShortcutOptions
    ) => Promise<void>;
    deleteSteamShortcut: (shop: GameShop, objectId: string) => Promise<void>;
    checkSteamShortcut: (shop: GameShop, objectId: string) => Promise<boolean>;

    /* Download sources */
    addDownloadSource: (url: string) => Promise<DownloadSource>;
    removeDownloadSource: (
      removeAll = false,
      downloadSourceId?: string
    ) => Promise<void>;
    getDownloadSources: () => Promise<DownloadSource[]>;
    syncDownloadSources: () => Promise<void>;
    getDownloadSourcesCheckBaseline: () => Promise<string | null>;
    getDownloadSourcesSinceValue: () => Promise<string | null>;

    /* Hardware */
    getDiskFreeSpace: (path: string) => Promise<DiskUsage | null>;
    checkFolderWritePermission: (path: string) => Promise<boolean>;
    getNetworkInterfaces: () => Promise<NetworkInterface[]>;

    /* Cloud save */
    uploadSaveGame: (
      objectId: string,
      shop: GameShop,
      downloadOptionTitle: string | null
    ) => Promise<void>;
    downloadGameArtifact: (
      objectId: string,
      shop: GameShop,
      gameArtifactId: string
    ) => Promise<void>;
    exportGameArtifact: (
      gameArtifactId: string,
      suggestedName: string,
      onProgress?: (progress: LegacySaveExportProgress) => void
    ) => Promise<LegacySaveExportResult>;
    cancelGameArtifactExport: () => Promise<boolean>;
    getGameArtifacts: (
      objectId: string,
      shop: GameShop
    ) => Promise<GameArtifact[]>;
    getGameBackupPreview: (
      objectId: string,
      shop: GameShop
    ) => Promise<LudusaviBackup | null>;
    selectGameBackupPath: (
      shop: GameShop,
      objectId: string,
      backupPath: string | null
    ) => Promise<void>;
    onBackupDownloadComplete: (
      objectId: string,
      shop: GameShop,
      cb: (success: boolean) => void
    ) => () => Electron.IpcRenderer;
    onUploadComplete: (
      objectId: string,
      shop: GameShop,
      cb: () => void
    ) => () => Electron.IpcRenderer;
    onBackupDownloadProgress: (
      objectId: string,
      shop: GameShop,
      cb: (progress: AxiosProgressEvent) => void
    ) => () => Electron.IpcRenderer;

    /* Clipboard */
    clipboard: {
      writeText: (text: string) => Promise<void>;
    };

    /* Misc */
    openExternal: (src: string) => Promise<void>;
    openCheckout: () => Promise<void>;
    getCloudIframeUrl: () => Promise<string>;
    getVersion: () => Promise<string>;
    isStaging: () => Promise<boolean>;
    ping: () => string;
    getDefaultDownloadsPath: () => Promise<string>;
    isPortableVersion: () => Promise<boolean>;
    showOpenDialog: (
      options: Electron.OpenDialogOptions
    ) => Promise<Electron.OpenDialogReturnValue>;
    readDirectory: (path: string) => Promise<FileExplorerEntry[]>;
    getPathInfo: (path: string) => Promise<FileExplorerPathInfo>;
    listDrives: () => Promise<string[]>;
    showItemInFolder: (path: string) => Promise<void>;
    getImageDataUrl: (imageUrl: string) => Promise<string | null>;
    getProcessedFriendImage: (
      imageUrl: string | null,
      options: { width: number; height: number; preserveAnimation?: boolean }
    ) => Promise<string | null>;
    hydraApi: {
      get: <T = unknown>(
        url: string,
        options?: {
          params?: unknown;
          needsAuth?: boolean;
          needsSubscription?: boolean;
          ifModifiedSince?: Date;
        }
      ) => Promise<T>;
      post: <T = unknown>(
        url: string,
        options?: {
          data?: unknown;
          needsAuth?: boolean;
          needsSubscription?: boolean;
        }
      ) => Promise<T>;
      put: <T = unknown>(
        url: string,
        options?: {
          data?: unknown;
          needsAuth?: boolean;
          needsSubscription?: boolean;
        }
      ) => Promise<T>;
      patch: <T = unknown>(
        url: string,
        options?: {
          data?: unknown;
          needsAuth?: boolean;
          needsSubscription?: boolean;
        }
      ) => Promise<T>;
      delete: <T = unknown>(
        url: string,
        options?: {
          needsAuth?: boolean;
          needsSubscription?: boolean;
        }
      ) => Promise<T>;
    };
    canInstallCommonRedist: () => Promise<boolean>;
    installCommonRedist: () => Promise<void>;
    installHydraDeckyPlugin: () => Promise<{
      success: boolean;
      path: string;
      currentVersion: string | null;
      expectedVersion: string;
      error?: string;
    }>;
    getHydraDeckyPluginInfo: () => Promise<{
      installed: boolean;
      version: string | null;
      path: string;
      outdated: boolean;
      expectedVersion: string | null;
    }>;
    checkHomebrewFolderExists: () => Promise<boolean>;
    onCommonRedistProgress: (
      cb: (value: { log: string; complete: boolean }) => void
    ) => () => Electron.IpcRenderer;
    onPreflightProgress: (
      cb: (value: { status: string; detail: string | null }) => void
    ) => () => Electron.IpcRenderer;
    resetCommonRedistPreflight: () => Promise<void>;
    saveTempFile: (fileName: string, fileData: Uint8Array) => Promise<string>;
    deleteTempFile: (filePath: string) => Promise<void>;
    platform: NodeJS.Platform;
    isWayland: boolean;

    /* Auto update */
    onAutoUpdaterEvent: (
      cb: (event: AppUpdaterEvent) => void
    ) => () => Electron.IpcRenderer;
    checkForUpdates: () => Promise<boolean>;
    restartAndInstallUpdate: () => Promise<void>;

    /* Auth */
    getAuth: () => Promise<Auth | null>;
    signOut: () => Promise<void>;
    openAuthWindow: (page: AuthPage) => Promise<void>;
    minimizeAuthWindow: () => Promise<void>;
    closeAuthWindow: () => Promise<void>;
    getSessionHash: () => Promise<string | null>;
    onSignIn: (cb: () => void) => () => Electron.IpcRenderer;
    onAccountUpdated: (cb: () => void) => () => Electron.IpcRenderer;
    onSignOut: (cb: () => void) => () => Electron.IpcRenderer;

    /* User */
    getComparedUnlockedAchievements: (
      objectId: string,
      shop: GameShop,
      userId: string
    ) => Promise<ComparedAchievements>;
    getUnlockedAchievements: (
      objectId: string,
      shop: GameShop
    ) => Promise<UserAchievement[]>;
    getRetroAchievementsAchievements: (
      objectId: string,
      shop: GameShop,
      raGameId?: number
    ) => Promise<UserAchievement[] | null>;
    resetRetroAchievementsAchievements: () => Promise<void>;

    /* Profile */
    getMe: () => Promise<UserDetails | null>;
    updateProfile: (
      updateProfile: UpdateProfileRequest
    ) => Promise<UserProfile>;
    updateProfile: (updateProfile: UpdateProfileProps) => Promise<UserProfile>;
    getProfileImageMetadata: (
      path: string
    ) => Promise<{ mimeType: string | null; isAnimated: boolean }>;
    processProfileImage: (
      path: string
    ) => Promise<{ imagePath: string; mimeType: string }>;
    cropProfileImage: (
      path: string,
      params: {
        left: number;
        top: number;
        width: number;
        height: number;
        outputWidth: number;
        outputHeight: number;
        rotation?: number;
      }
    ) => Promise<{ imagePath: string }>;
    onSyncFriendRequests: (
      cb: (friendRequests: FriendRequestSync) => void
    ) => () => Electron.IpcRenderer;
    onSyncNotificationCount: (
      cb: (notification: NotificationSync) => void
    ) => () => Electron.IpcRenderer;
    syncFriendRequests: (friendRequestCount: number) => Promise<void>;

    /* Notifications */
    publishNewRepacksNotification: (newRepacksCount: number) => Promise<void>;
    getLocalNotifications: () => Promise<LocalNotification[]>;
    getLocalNotificationsCount: () => Promise<number>;
    markLocalNotificationRead: (id: string) => Promise<void>;
    markLocalNotificationUnread: (id: string) => Promise<void>;
    markAllLocalNotificationsRead: () => Promise<void>;
    deleteLocalNotification: (id: string) => Promise<void>;
    clearAllLocalNotifications: () => Promise<void>;
    onLocalNotificationCreated: (
      cb: (notification: LocalNotification) => void
    ) => () => Electron.IpcRenderer;
    onAchievementUnlocked: (
      cb: (
        position?: AchievementCustomNotificationPosition,
        achievements?: AchievementNotificationInfo[]
      ) => void
    ) => () => Electron.IpcRenderer;
    onInAppAchievementUnlocked?: (
      cb: (
        position: AchievementCustomNotificationPosition,
        achievements: AchievementNotificationInfo[]
      ) => void
    ) => () => Electron.IpcRenderer;
    onPrepareAchievementNotification: (
      cb: (request: AchievementNotificationRequest) => void
    ) => () => Electron.IpcRenderer;
    onStartAchievementNotification: (
      cb: (requestId: string) => void
    ) => () => Electron.IpcRenderer;
    achievementNotificationHostReady: () => Promise<void>;
    achievementNotificationContentReady: (requestId: string) => Promise<void>;
    achievementNotificationFinished: (requestId: string) => Promise<void>;
    achievementNotificationFailed: (
      requestId?: string,
      reason?: string
    ) => Promise<void>;
    updateAchievementCustomNotificationWindow: () => Promise<void>;
    showAchievementTestNotification: () => Promise<void>;

    /* Themes */
    addCustomTheme: (theme: Theme) => Promise<void>;
    getAllCustomThemes: () => Promise<Theme[]>;
    deleteAllCustomThemes: () => Promise<void>;
    deleteCustomTheme: (themeId: string) => Promise<void>;
    updateCustomTheme: (themeId: string, code: string) => Promise<void>;
    getCustomThemeById: (themeId: string) => Promise<Theme | null>;
    getActiveCustomTheme: () => Promise<Theme | null>;
    toggleCustomTheme: (themeId: string, isActive: boolean) => Promise<void>;
    copyThemeAchievementSound: (
      themeId: string,
      sourcePath: string
    ) => Promise<void>;
    removeThemeAchievementSound: (themeId: string) => Promise<void>;
    getThemeSoundPath: (themeId: string) => Promise<string | null>;
    getThemeSoundDataUrl: (themeId: string) => Promise<string | null>;
    importThemeSoundFromStore: (
      themeId: string,
      themeName: string,
      storeUrl: string
    ) => Promise<void>;

    /* Editor */
    openEditorWindow: (themeId: string) => Promise<void>;
    onCustomThemeUpdated: (cb: () => void) => () => Electron.IpcRenderer;
    closeEditorWindow: (themeId?: string) => Promise<void>;

    /* Game Launcher Window */
    showGameLauncherWindow: () => Promise<void>;
    closeGameLauncherWindow: () => Promise<void>;
    openMainWindow: () => Promise<void>;
    isMainWindowOpen: () => Promise<boolean>;

    /* Main Window Controls */
    minimizeMainWindow: () => Promise<void>;
    toggleMaximizeMainWindow: () => Promise<void>;
    closeMainWindow: () => Promise<void>;
    isMainWindowMaximized: () => Promise<boolean>;
    onWindowMaximizeChange: (cb: (isMaximized: boolean) => void) => () => void;

    /* Big Picture Window */
    openBigPictureWindow: () => Promise<void>;

    /* Friends Window */
    openFriendsWindow: () => Promise<void>;
    minimizeFriendsWindow: () => Promise<void>;
    closeFriendsWindow: () => Promise<void>;
    openFriendProfileInMainWindow: (userId: string) => Promise<void>;
    openAddFriendModalInMainWindow: () => Promise<void>;
    onOpenAddFriendModal: (cb: () => void) => () => Electron.IpcRenderer;
    onFriendsUpdated: (cb: () => void) => () => Electron.IpcRenderer;
    onFriendPresence: (
      cb: (presence: FriendPresenceSync) => void
    ) => () => Electron.IpcRenderer;
    onProfileUpdated: (cb: () => void) => () => Electron.IpcRenderer;
    onNavigate: (cb: (path: string) => void) => () => Electron.IpcRenderer;

    /* Download Options */
    onNewDownloadOptions: (
      cb: (gamesWithNewOptions: { gameId: string; count: number }[]) => void
    ) => () => Electron.IpcRenderer;

    /* LevelDB Generic CRUD */
    leveldb: {
      get: (
        key: string,
        sublevelName?: string | null,
        valueEncoding?: "json" | "utf8"
      ) => Promise<unknown>;
      put: (
        key: string,
        value: unknown,
        sublevelName?: string | null,
        valueEncoding?: "json" | "utf8"
      ) => Promise<void>;
      del: (key: string, sublevelName?: string | null) => Promise<void>;
      clear: (sublevelName: string) => Promise<void>;
      values: (sublevelName: string) => Promise<unknown[]>;
      iterator: (sublevelName: string) => Promise<[string, unknown][]>;
    };

    /* Transfer Game */
    getAvailableDrives: () => Promise<DriveInfo[]>;
    transferGameFiles: (
      shop: GameShop,
      objectId: string,
      destParent: string
    ) => Promise<{
      ok: boolean;
      error?: string;
      needed?: number;
      available?: number;
      newExePath?: string;
    }>;

    // Cancel for game transfers
    cancelGameTransfer: (shop: GameShop, objectId: string) => Promise<void>;

    /* Event listeners for transfer progress */
    on: (channel: string, listener: (...args) => void) => void;
    off: (channel: string, listener: (...args) => void) => void;
  }

  interface Window {
    electron: Electron;
  }
}
