import "./styles.scss";

import cn from "classnames";
import { AnimatePresence, motion } from "framer-motion";
import {
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { IS_BROWSER } from "../../../constants";
import { useNavigationScreenActions } from "../../../hooks";
import {
  useNavigationIsFocused,
  useVirtualKeyboardStore,
} from "../../../stores";
import { FocusRegionContext } from "../../context";
import { Backdrop } from "../backdrop";
import { FocusItem } from "../focus-item";
import { NavigationLayer } from "../navigation-layer";
import { VerticalFocusGroup } from "../vertical-focus-group";
import { MODAL_OWNED_OVERLAY_ATTRIBUTE } from "../modal";

export interface SidebarModalTab<TabId extends string = string> {
  id: TabId;
  label: ReactNode;
  content: ReactNode;
  disabled?: boolean;
}

export interface SidebarModalProps<TabId extends string = string> {
  visible: boolean;
  onClose: () => void;
  title: ReactNode;
  tabs: SidebarModalTab<TabId>[];
  activeTabId?: TabId;
  defaultActiveTabId?: TabId;
  onActiveTabChange?: (tabId: TabId) => void;
  contentEntryFocusId?: string;
  className?: string;
  ariaLabel?: string;
  closeOnBackdrop?: boolean;
  closeOnEscape?: boolean;
  closeOnB?: boolean;
  coverImage?: string;
}

function normalizeIdSegment(value: string) {
  return value.replace(/[^a-zA-Z0-9_-]/g, "-");
}

function getFirstEnabledTab<TabId extends string>(
  tabs: SidebarModalTab<TabId>[]
) {
  return tabs.find((tab) => !tab.disabled) ?? tabs[0] ?? null;
}

interface ActiveTabMetrics {
  top: number;
  height: number;
}

function SidebarModalTabButton<TabId extends string = string>({
  tab,
  focusId,
  isActive,
  onActivate,
  registerElement,
}: Readonly<{
  tab: SidebarModalTab<TabId>;
  focusId: string;
  isActive: boolean;
  onActivate: (tabId: TabId) => void;
  registerElement: (tabId: TabId, element: HTMLButtonElement | null) => void;
}>) {
  const isFocused = useNavigationIsFocused(focusId);
  const wasFocusedRef = useRef(false);
  const setElement = useCallback(
    (element: HTMLButtonElement | null) => registerElement(tab.id, element),
    [registerElement, tab.id]
  );

  useEffect(() => {
    const gainedFocus = isFocused && !wasFocusedRef.current;

    if (gainedFocus && !tab.disabled && !isActive) {
      onActivate(tab.id);
    }

    wasFocusedRef.current = isFocused;
  }, [isActive, isFocused, onActivate, tab.disabled, tab.id]);

  return (
    <FocusItem
      id={focusId}
      navigationState={tab.disabled ? "disabled" : "active"}
      actions={{ primary: () => onActivate(tab.id) }}
      asChild
    >
      <button
        type="button"
        ref={setElement}
        className="sidebar-modal__tab"
        data-active={isActive || undefined}
        disabled={tab.disabled}
        onClick={() => onActivate(tab.id)}
      >
        <span className="sidebar-modal__tab-label">{tab.label}</span>
      </button>
    </FocusItem>
  );
}

export function SidebarModal<TabId extends string = string>({
  visible,
  onClose,
  title,
  tabs,
  activeTabId,
  defaultActiveTabId,
  onActiveTabChange,
  contentEntryFocusId,
  className,
  ariaLabel,
  coverImage,
  closeOnBackdrop = true,
  closeOnEscape = true,
  closeOnB = true,
}: Readonly<SidebarModalProps<TabId>>) {
  const generatedId = useId().replaceAll(":", "");
  const resolvedAriaLabel =
    ariaLabel ?? (typeof title === "string" ? title : "Sidebar modal");
  const modalContentRef = useRef<HTMLDivElement | null>(null);
  const tabElementsRef = useRef<
    Partial<Record<TabId, HTMLButtonElement | null>>
  >({});
  const firstEnabledTab = useMemo(() => getFirstEnabledTab(tabs), [tabs]);
  const initialTabId =
    defaultActiveTabId ?? activeTabId ?? firstEnabledTab?.id ?? "";
  const [internalActiveTabId, setInternalActiveTabId] = useState<TabId | "">(
    initialTabId
  );
  const [activeTabMetrics, setActiveTabMetrics] =
    useState<ActiveTabMetrics | null>(null);
  const virtualKeyboardTarget = useVirtualKeyboardStore(
    (state) => state.target
  );
  const resolvedActiveTabId = activeTabId ?? internalActiveTabId;
  const activeTab =
    tabs.find((tab) => tab.id === resolvedActiveTabId && !tab.disabled) ??
    firstEnabledTab;
  const modalId = `sidebar-modal-${generatedId}`;
  const tabsRegionId = `${modalId}-tabs`;
  const contentRegionId = `${modalId}-content`;
  const getTabFocusId = useCallback(
    (tabId: string) =>
      `${modalId}-tab-${normalizeIdSegment(tabId || "untitled")}`,
    [modalId]
  );
  const activeTabFocusId = activeTab ? getTabFocusId(activeTab.id) : undefined;
  const isActiveTabFocused = useNavigationIsFocused(activeTabFocusId ?? "");
  const isVirtualKeyboardOpen = virtualKeyboardTarget !== null;

  const isTopMostModal = () => {
    const openModals = document.querySelectorAll("[role=dialog]");
    return (
      openModals.length &&
      openModals[openModals.length - 1] === modalContentRef.current
    );
  };

  const handleClose = useCallback(() => {
    onClose();
  }, [onClose]);

  const setActiveTab = useCallback(
    (tabId: TabId) => {
      if (activeTabId === undefined) {
        setInternalActiveTabId(tabId);
      }

      onActiveTabChange?.(tabId);
    },
    [activeTabId, onActiveTabChange]
  );

  const registerTabElement = useCallback(
    (tabId: TabId, element: HTMLButtonElement | null) => {
      tabElementsRef.current[tabId] = element;
    },
    []
  );

  const updateActiveTabMetrics = useCallback(() => {
    if (!visible || !activeTab) {
      setActiveTabMetrics(null);
      return;
    }

    const activeTabElement = tabElementsRef.current[activeTab.id];

    if (!activeTabElement) {
      setActiveTabMetrics(null);
      return;
    }

    const nextMetrics = {
      top: activeTabElement.offsetTop,
      height: activeTabElement.offsetHeight,
    };

    setActiveTabMetrics((currentMetrics) => {
      if (
        currentMetrics?.top === nextMetrics.top &&
        currentMetrics.height === nextMetrics.height
      ) {
        return currentMetrics;
      }

      return nextMetrics;
    });
  }, [activeTab, visible]);

  useEffect(() => {
    if (!visible || !firstEnabledTab) return;

    const hasActiveVisibleTab = tabs.some(
      (tab) => tab.id === resolvedActiveTabId && !tab.disabled
    );

    if (!hasActiveVisibleTab) {
      setActiveTab(firstEnabledTab.id);
    }
  }, [firstEnabledTab, resolvedActiveTabId, setActiveTab, tabs, visible]);

  useLayoutEffect(() => {
    updateActiveTabMetrics();
  }, [tabs, updateActiveTabMetrics]);

  useEffect(() => {
    if (!visible) return;

    const activeTabElement = activeTab
      ? tabElementsRef.current[activeTab.id]
      : null;
    const resizeObserver =
      typeof ResizeObserver === "undefined"
        ? null
        : new ResizeObserver(updateActiveTabMetrics);
    const animationFrameId = globalThis.requestAnimationFrame(
      updateActiveTabMetrics
    );

    if (modalContentRef.current) {
      resizeObserver?.observe(modalContentRef.current);
    }

    if (activeTabElement) {
      resizeObserver?.observe(activeTabElement);
    }

    globalThis.window.addEventListener("resize", updateActiveTabMetrics);

    return () => {
      globalThis.cancelAnimationFrame(animationFrameId);
      resizeObserver?.disconnect();
      globalThis.window.removeEventListener("resize", updateActiveTabMetrics);
    };
  }, [activeTab, updateActiveTabMetrics, visible]);

  useNavigationScreenActions(
    visible && closeOnB && !isVirtualKeyboardOpen
      ? {
          press: {
            b: () => {
              if (!isTopMostModal()) return;
              handleClose();
            },
          },
        }
      : {}
  );

  useEffect(() => {
    if (!visible || !closeOnEscape) return;

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      if (event.defaultPrevented) return;
      if (useVirtualKeyboardStore.getState().target !== null) return;
      if (!isTopMostModal()) return;

      handleClose();
    };

    globalThis.window.addEventListener("keydown", onKeyDown);
    return () => globalThis.window.removeEventListener("keydown", onKeyDown);
  }, [closeOnEscape, handleClose, visible]);

  useEffect(() => {
    if (!visible || !closeOnBackdrop) return;

    const onPointerDown = (event: PointerEvent) => {
      if (!isTopMostModal()) return;

      const target = event.target as Node | null;
      const targetElement = target instanceof Element ? target : null;
      const clickedOwnedOverlay = targetElement?.closest(
        `[${MODAL_OWNED_OVERLAY_ATTRIBUTE}]`
      );
      const clickedOutside =
        modalContentRef.current &&
        target &&
        !modalContentRef.current.contains(target) &&
        !clickedOwnedOverlay;

      if (clickedOutside) {
        handleClose();
      }
    };

    globalThis.window.addEventListener("pointerdown", onPointerDown, true);
    return () =>
      globalThis.window.removeEventListener("pointerdown", onPointerDown, true);
  }, [closeOnBackdrop, handleClose, visible]);

  if (!IS_BROWSER) return null;

  const portalTarget =
    document.getElementById("big-picture") ??
    document.getElementById("root") ??
    document.body;

  return createPortal(
    <FocusRegionContext.Provider value={null}>
      <AnimatePresence>
        {visible && (
          <Backdrop>
            <motion.aside
              id={modalId}
              role="dialog"
              aria-modal="true"
              aria-label={resolvedAriaLabel}
              ref={modalContentRef}
              data-hydra-dialog
              className={cn("sidebar-modal", className)}
              initial={{ opacity: 0, y: 24, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.98 }}
              transition={{
                duration: 0.22,
                ease: [0.22, 1, 0.36, 1],
              }}
            >
              <NavigationLayer
                rootRegionId={modalContentRef.current?.id}
                initialFocusId={activeTabFocusId}
              >
                <aside className="sidebar-modal__sidebar">
                  <div className="sidebar-modal__header">
                    {coverImage && (
                      <div className="sidebar-modal__header-cover-image">
                        <img src={coverImage} alt="" aria-hidden="true" />
                      </div>
                    )}

                    <div className="sidebar-modal__title">{title}</div>
                  </div>

                  <div className="sidebar-modal__divider" />

                  <VerticalFocusGroup
                    regionId={tabsRegionId}
                    className="sidebar-modal__tabs"
                    style={{ gap: 0 }}
                    navigationOverrides={{
                      right: activeTab
                        ? {
                            type: "region",
                            regionId: contentRegionId,
                            entryDirection: "right",
                            initialFocusId: contentEntryFocusId,
                            preferRememberedFocus: true,
                          }
                        : { type: "block" },
                    }}
                  >
                    {activeTabMetrics && (
                      <motion.div
                        className="sidebar-modal__tab-active-indicator"
                        data-highlighted={isActiveTabFocused || undefined}
                        style={{ height: activeTabMetrics.height }}
                        animate={{ y: activeTabMetrics.top }}
                        initial={false}
                        transition={{
                          duration: 0.22,
                          ease: [0.22, 1, 0.36, 1],
                        }}
                      />
                    )}

                    {tabs.map((tab) => (
                      <SidebarModalTabButton
                        key={tab.id}
                        tab={tab}
                        focusId={getTabFocusId(tab.id)}
                        isActive={tab.id === activeTab?.id}
                        onActivate={setActiveTab}
                        registerElement={registerTabElement}
                      />
                    ))}
                  </VerticalFocusGroup>
                </aside>

                <VerticalFocusGroup
                  regionId={contentRegionId}
                  className="sidebar-modal__content"
                  navigationOverrides={{
                    left: activeTabFocusId
                      ? {
                          type: "region",
                          regionId: tabsRegionId,
                          entryDirection: "left",
                          initialFocusId: activeTabFocusId,
                          preferRememberedFocus: true,
                        }
                      : { type: "block" },
                  }}
                >
                  {activeTab?.content}
                </VerticalFocusGroup>
              </NavigationLayer>
            </motion.aside>
          </Backdrop>
        )}
      </AnimatePresence>
    </FocusRegionContext.Provider>,
    portalTarget
  );
}
